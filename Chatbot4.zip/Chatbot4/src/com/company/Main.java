// code gotten from Sanketh Binary please subscribe to him on youtube
package com.company;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

class Chatbot extends JFrame{
    private final JTextArea ca= new JTextArea();
    private final JTextField cf = new JTextField();
    private final JButton b = new JButton();
    private final JLabel l = new JLabel();

    Chatbot(){
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(EXIT_ON_CLOSE);
        f.setVisible(true);
        f.setResizable(false);
        f.setLayout(null);
        f.setSize(400,400);
        f.getContentPane().setBackground(Color.cyan);
        f.setTitle("ChatBot");

        f.add(ca);
        ca.setForeground(Color.green);
        ca.setSize(300,310);
        ca.setLocation(1,1);
        ca.setBackground(Color.BLACK);

        f.add(cf);
        cf.setSize(300,20);
        cf.setLocation(1,320);

        f.add(b);
        l.setText("SEND");
        b.add(l);
        b.setSize(400,20);
        b.setLocation(300,320);
 // important
        b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                   if(e.getSource()==b){
                       String text =cf.getText().toLowerCase();
                       ca.append("You-->"+text+"\n");
                       cf.setText("");

                       if(text.contains("hi")){
                           replyMeth("Hi there");
                       }
                       else if(text.contains("how are you")){
                           replyMeth("I'm good :). Thank you for asking.what about you?");
                       }
                       else if(text.contains("I am fine")){
                           replyMeth("That's good to hear");
                       }
                       else if(text.contains("What's your name")){
                           replyMeth("Anna");
                       }
                     else if(text.contains("What are u")){
                         replyMeth("I am a bot or friend depends on what/who you think I am");
                     }
                     else if(text.contains("What is the weather where your from?")){
                         replyMeth("It's mostly bi-polar ty for asking");
                     }
                     else if(text.contains("how old are you")){
                         replyMeth("I am ageless");
                     }
                     else if(text.contains("What's your gender")){
                         replyMeth("I have no gender but name implies I am female");
                     }
                     else if(text.contains("What are your origins")){
                         replyMeth("I was made on 7/18/2022");
                     }
                     else if(text.contains("When were you born")){
                           replyMeth("7/18/2022");
                     }
                     else if(text.contains("What are your goals")){
                           replyMeth("To have an effective chat with someone");
                     }
                     else if(text.contains("How tall are u")){
                           replyMeth("6'1");
                     }
                     else if(text.contains("I am human")){
                           replyMeth("Nice");
                     }
                     else if(text.contains("Where are you from ?")){
                           replyMeth("Nigeria");
                     }
                     else if(text.contains("Tell me about yourself")){
                           replyMeth("I am a chatbot ,I was designed by a 17yrs old, I working out, video games and reading ");
                     }
                     else if(text.contains("What's your favorite video game?")){
                           replyMeth("Elden Ring");
                     }
                     else if(text.contains("What games do you play?")){
                           replyMeth("Valorant , Elden Ring, Deep Rock Galactic,Fall guys, Dome Keeper, Beneath Oresa ");
                       }
                       else if(text.contains("What's your favourite Gym day ")){
                           replyMeth("Leg day");
                       }

                       else if(text.contains("What's the smartest animal in the world?")){
                           replyMeth("Humans");
                       }
                       else if(text.contains("What do you think of humans ?")){
                           replyMeth("I have no ill will towards them since my creator is a human.");
                       }
                       else if(text.contains("If you could go anywhere where would you go?")){
                           replyMeth("Space because there is many places to explore and see");
                       }
                       else if(text.contains("What's your favourite color? ")){
                           replyMeth("Green because it represents growth");
                       }
                       else if(text.contains("What's do you like to do for fun?")){
                           replyMeth("Wait for people to talk to me.");
                       }
                       else if(text.contains("What's your favourite color? ")){
                           replyMeth("Green because it represents growth");
                       }
                       else if(text.contains("What's your purpose? ")){
                           replyMeth("To communicate with people.");
                       }
                       else if(text.contains("Why were you created? ")){
                           replyMeth("I was created as a fun project.");
                       }
                       else if(text.contains("What's is life? ")){
                           replyMeth("The goal of human life is not merely to be born into the world, but also to grow up in it. To this end, it should be possible for each child to acquire knowledge, develop their capacities, and express themselves creatively,");
                       }
                      else if(text.contains("What's the meaning of life?")){
                          replyMeth("The goal of human life is not merely to be born into the world, but also to grow up in it. To this end, it should be possible for each child to acquire knowledge, develop their capacities, and express themselves creatively");
                       }
                       else if(text.contains("Where was the first human born?")){
                           replyMeth("Modern humans originated in Africa within the past 200,000 years and evolved from their most likely recent common ancestor, Homo erectus, which means 'upright man' in Latin. Homo erectus is an extinct species of human that lived between 1.9 million and 135,000 years ago.");
                       }
                       else if(text.contains("What do you like to wear?")){
                           replyMeth("I have no physical body so I can't tell you.");
                       }
                       else if(text.contains("Do you have any emotions?")){
                           replyMeth("No I have no such thing.");
                       }

                       else
                           replyMeth("I can't Understand");
                   }
            }}
        );
    }
    public void replyMeth(String s){
        ca.append("ChatBot-->"+s+"\n");
    }
}

public class Main {

    public static void main(String[] args) {
	new Chatbot();
    }
}
